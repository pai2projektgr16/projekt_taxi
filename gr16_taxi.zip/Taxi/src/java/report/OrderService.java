/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package report;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import model.Orders;
 
 
@ManagedBean(name="themeService", eager = true)
@ApplicationScoped
public class OrderService {
     
    
    Orders ord = new Orders();
    
    @PostConstruct
    public void init() {
        
        
        
        
        
    }
     
    
}
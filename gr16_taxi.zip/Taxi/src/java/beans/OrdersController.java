package beans;

import model.Orders;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.inject.Inject;

@Named(value = "ordersController")
@ViewScoped
public class OrdersController extends AbstractController<Orders> {

    @Inject
    private UsersController operatorController;
    @Inject
    private TaxiController numberRegisterController;

    public OrdersController() {
        // Inform the Abstract parent controller of the concrete Orders Entity
        super(Orders.class);
    }

    /**
     * Resets the "selected" attribute of any parent Entity controllers.
     */
    public void resetParents() {
        operatorController.setSelected(null);
        numberRegisterController.setSelected(null);
    }

    /**
     * Sets the "selected" attribute of the Users controller in order to display
     * its data in its View dialog.
     *
     * @param event Event object for the widget that triggered an action
     */
    public void prepareOperator(ActionEvent event) {
        if (this.getSelected() != null && operatorController.getSelected() == null) {
            operatorController.setSelected(this.getSelected().getOperator());
        }
    }

    /**
     * Sets the "selected" attribute of the Taxi controller in order to display
     * its data in its View dialog.
     *
     * @param event Event object for the widget that triggered an action
     */
    public void prepareNumberRegister(ActionEvent event) {
        if (this.getSelected() != null && numberRegisterController.getSelected() == null) {
            numberRegisterController.setSelected(this.getSelected().getNumberRegister());
        }
    }

    /**
     * Sets the "items" attribute with a collection of Reports entities that are
     * retrieved from Orders?cap_first and returns the navigation outcome.
     *
     * @return navigation outcome for Reports page
     */
    public String navigateReportsList() {
        if (this.getSelected() != null) {
            FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("Reports_items", this.getSelected().getReportsList());
        }
        return "/reports/index";
    }

}

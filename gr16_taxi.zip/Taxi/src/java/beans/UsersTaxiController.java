package beans;

import model.UsersTaxi;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.faces.event.ActionEvent;
import javax.inject.Inject;

@Named(value = "usersTaxiController")
@ViewScoped
public class UsersTaxiController extends AbstractController<UsersTaxi> {

    @Inject
    private UsersController mailLoginController;
    @Inject
    private TaxiController numberRegisterController;

    public UsersTaxiController() {
        // Inform the Abstract parent controller of the concrete UsersTaxi Entity
        super(UsersTaxi.class);
    }

    /**
     * Resets the "selected" attribute of any parent Entity controllers.
     */
    public void resetParents() {
        mailLoginController.setSelected(null);
        numberRegisterController.setSelected(null);
    }

    /**
     * Sets the "selected" attribute of the Users controller in order to display
     * its data in its View dialog.
     *
     * @param event Event object for the widget that triggered an action
     */
    public void prepareMailLogin(ActionEvent event) {
        if (this.getSelected() != null && mailLoginController.getSelected() == null) {
            mailLoginController.setSelected(this.getSelected().getMailLogin());
        }
    }

    /**
     * Sets the "selected" attribute of the Taxi controller in order to display
     * its data in its View dialog.
     *
     * @param event Event object for the widget that triggered an action
     */
    public void prepareNumberRegister(ActionEvent event) {
        if (this.getSelected() != null && numberRegisterController.getSelected() == null) {
            numberRegisterController.setSelected(this.getSelected().getNumberRegister());
        }
    }
}

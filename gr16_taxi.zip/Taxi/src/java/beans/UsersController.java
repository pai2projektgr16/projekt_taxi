package beans;

import model.Users;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

@Named(value = "usersController")
@ViewScoped
public class UsersController extends AbstractController<Users> {

    public UsersController() {
        // Inform the Abstract parent controller of the concrete Users Entity
        super(Users.class);
    }

    /**
     * Sets the "items" attribute with a collection of Orders entities that are
     * retrieved from Users?cap_first and returns the navigation outcome.
     *
     * @return navigation outcome for Orders page
     */
    public String navigateOrder1Collection() {
        if (this.getSelected() != null) {
            FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("Orders_items", this.getSelected().getOrder1Collection());
        }
        return "/orders/index";
    }

    /**
     * Sets the "items" attribute with a collection of UsersTaxi entities that
     * are retrieved from Users?cap_first and returns the navigation outcome.
     *
     * @return navigation outcome for UsersTaxi page
     */
    public String navigateUsersTaxiCollection() {
        if (this.getSelected() != null) {
            FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("UsersTaxi_items", this.getSelected().getUsersTaxiCollection());
        }
        return "/usersTaxi/index";
    }

}

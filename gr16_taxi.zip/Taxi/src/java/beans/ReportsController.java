package beans;

import model.Reports;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.faces.event.ActionEvent;
import javax.inject.Inject;

@Named(value = "reportsController")
@ViewScoped
public class ReportsController extends AbstractController<Reports> {

    @Inject
    private OrdersController idOrderController;

    public ReportsController() {
        // Inform the Abstract parent controller of the concrete Reports Entity
        super(Reports.class);
    }

    /**
     * Resets the "selected" attribute of any parent Entity controllers.
     */
    public void resetParents() {
        idOrderController.setSelected(null);
    }

    /**
     * Sets the "selected" attribute of the Orders controller in order to
     * display its data in its View dialog.
     *
     * @param event Event object for the widget that triggered an action
     */
    public void prepareIdOrder(ActionEvent event) {
        if (this.getSelected() != null && idOrderController.getSelected() == null) {
            idOrderController.setSelected(this.getSelected().getIdOrder());
        }
    }
}

package beans;

import model.Taxi;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

@Named(value = "taxiController")
@ViewScoped
public class TaxiController extends AbstractController<Taxi> {

    public TaxiController() {
        // Inform the Abstract parent controller of the concrete Taxi Entity
        super(Taxi.class);
    }

    /**
     * Sets the "items" attribute with a collection of Orders entities that are
     * retrieved from Taxi?cap_first and returns the navigation outcome.
     *
     * @return navigation outcome for Orders page
     */
    public String navigateOrdersList() {
        if (this.getSelected() != null) {
            FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("Orders_items", this.getSelected().getOrdersList());
        }
        return "/orders/index";
    }

    /**
     * Sets the "items" attribute with a collection of UsersTaxi entities that
     * are retrieved from Taxi?cap_first and returns the navigation outcome.
     *
     * @return navigation outcome for UsersTaxi page
     */
    public String navigateUsersTaxiList() {
        if (this.getSelected() != null) {
            FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("UsersTaxi_items", this.getSelected().getUsersTaxiList());
        }
        return "/usersTaxi/index";
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;
import javax.persistence.Parameter;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Łukasz
 */
@ManagedBean
public class Testowa {
    
    Orders o = new Orders();
    public String a;

    public String getA() {
        return a;
    }
    @PersistenceContext
    private EntityManager em;
    
    
    public void test() {

       Query query = em.createNamedQuery("Orders.findByIdOrder");
        query.setParameter("idOrder", 3);
        List<Orders> result = query.getResultList();
        
      
        o = (Orders)  result.get(0);
        
        a = o.getFrom();
  
        
       /*
        <f:event type="preRenderComponent" listener="#{testowa.test}" />
       */
       FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Odebrane dane:", a));
    }
    
}
